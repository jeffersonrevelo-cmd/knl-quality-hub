// KNL Quality Hub — Service Worker v5
const CACHE = 'knl-v5';

self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open(CACHE).then(function(cache){
      return fetch('/index.html').then(function(res){
        return cache.put('/index.html', res);
      }).then(function(){
        return fetch('/').then(function(res){ return cache.put('/', res); });
      }).then(function(){
        var others = ['/manifest.json','/dashboard.html','/icons/icon-192x192.png','/icons/icon-512x512.png','/icons/apple-touch-icon.png'];
        return Promise.allSettled(others.map(function(url){
          return fetch(url).then(function(res){ return cache.put(url, res); }).catch(function(){});
        }));
      });
    }).then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(e){
  e.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k !== CACHE; })
            .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(e){
  var url = e.request.url;
  if(e.request.method !== 'GET') return;
  if(url.startsWith('chrome-extension')) return;

  // NEVER intercept Netlify functions or API calls
  if(url.includes('/.netlify/') || 
     url.includes('supabase.co') || 
     url.includes('anthropic.com') ||
     url.includes('api.')) return;

  // Fonts — cache first
  if(url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com')){
    e.respondWith(
      caches.match(e.request).then(function(cached){
        if(cached) return cached;
        return fetch(e.request).then(function(res){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
          return res;
        }).catch(function(){ return new Response(''); });
      })
    );
    return;
  }

  // App shell — Cache First + background update
  e.respondWith(
    caches.match(e.request).then(function(cached){
      if(cached) return cached;
      return fetch(e.request).then(function(res){
        if(res.ok){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
        }
        return res;
      }).catch(function(){
        return caches.match('/index.html').then(function(page){
          return page || new Response('Offline', {status:503});
        });
      });
    })
  );
});
