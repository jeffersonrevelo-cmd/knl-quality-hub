# KNL Quality Hub — PWA en tu iPhone HOY
# Guía completa · Tiempo estimado: 15 minutos

══════════════════════════════════════════════════════════
OPCIÓN A — NETLIFY DROP (más fácil, sin código)
══════════════════════════════════════════════════════════

1. Ve a https://app.netlify.com/drop en tu Mac

2. Arrastra la CARPETA completa "knl-pwa" 
   (contiene: index.html, manifest.json, sw.js, carpeta icons/)

3. Netlify te da una URL automática tipo:
   https://knl-quality-xxx.netlify.app

4. En tu iPhone, abre Safari y ve a esa URL

5. Toca el botón compartir (□↑) en Safari

6. Toca "Añadir a pantalla de inicio"

7. Nombre: "KNL Quality" → Toca "Añadir"

✅ La app aparece en tu pantalla de inicio con ícono KNL
✅ Funciona offline (las auditorías se guardan localmente)
✅ Kevin y Hector hacen lo mismo con la misma URL


══════════════════════════════════════════════════════════
OPCIÓN B — GITHUB PAGES (gratis, tu propio dominio después)
══════════════════════════════════════════════════════════

1. Crea cuenta en https://github.com

2. Nuevo repositorio → nombre: "knl-quality-hub" → Public

3. Sube los archivos:
   - index.html
   - manifest.json
   - sw.js
   - icons/ (toda la carpeta)

4. Settings → Pages → Branch: main → Save

5. Tu URL: https://TU-USUARIO.github.io/knl-quality-hub

6. Instalar en iPhone igual que Opción A paso 4-7


══════════════════════════════════════════════════════════
OPCIÓN C — TU PROPIO SERVIDOR (cuando tengas dominio)
══════════════════════════════════════════════════════════

Cuando estés listo para knlqualityhub.com:

1. Comprar dominio en namecheap.com (~$12/año)

2. VPS en Hetzner (€4/mes):
   https://hetzner.com/cloud → CX22 Ubuntu 24.04

3. Instalar nginx:
   apt install nginx -y

4. Subir archivos:
   scp -r knl-pwa/ root@IP:/var/www/knlqualityhub/

5. Configurar nginx para servir la carpeta

6. SSL gratis con Let's Encrypt:
   certbot --nginx -d knlqualityhub.com

7. HTTPS requerido para que el Service Worker funcione en producción


══════════════════════════════════════════════════════════
VERIFICAR QUE LA PWA FUNCIONA
══════════════════════════════════════════════════════════

En Chrome desktop (para testing):
1. Abre la URL
2. F12 → Application → Manifest → debe mostrar tus datos
3. Application → Service Workers → debe decir "Activated"
4. Application → Cache Storage → debe mostrar "knl-quality-hub-v1"

En iPhone:
1. Instala la app desde Safari
2. Pon el iPhone en modo avión
3. Abre la app → debe funcionar completamente offline
4. Completa una auditoría → se guarda en localStorage
5. Vuelve a conectar → se sincroniza (cuando tengamos backend)


══════════════════════════════════════════════════════════
QUÉ FUNCIONA OFFLINE HOY
══════════════════════════════════════════════════════════

✅ Lista de fincas con scores
✅ Formulario completo de auditoría (39 ítems)
✅ Fotos (se guardan en memoria del dispositivo)
✅ Generación de PDF
✅ Score en tiempo real
✅ Historial local

⏳ Próximamente (cuando conectemos backend):
- Guardar auditorías en servidor
- Sincronización automática al recuperar internet
- Login real (Kevin, Hector, Jefferson)
- Notificaciones WhatsApp / Email reales
- Historial real desde base de datos


══════════════════════════════════════════════════════════
ESTRUCTURA DE ARCHIVOS QUE DEBES SUBIR
══════════════════════════════════════════════════════════

knl-pwa/
├── index.html          ← la app completa
├── manifest.json       ← configuración PWA
├── sw.js               ← service worker (offline)
└── icons/
    ├── icon-72x72.png
    ├── icon-96x96.png
    ├── icon-128x128.png
    ├── icon-144x144.png
    ├── icon-152x152.png
    ├── icon-192x192.png
    ├── icon-384x384.png
    ├── icon-512x512.png
    └── apple-touch-icon.png


══════════════════════════════════════════════════════════
PRÓXIMOS PASOS DESPUÉS DE VER EN EL IPHONE
══════════════════════════════════════════════════════════

Sesión siguiente:
1. Backend Node.js + PostgreSQL (ya tenemos el código)
2. Login real para Kevin, Hector y Jefferson
3. Las auditorías se guardan en la base de datos
4. Sincronización offline → online automática
5. Notificaciones WhatsApp Business API

Después:
→ React Native para App Store / Play Store oficial
→ knlqualityhub.com con HTTPS
→ KNLSOFT (portal de compras para clientes)
