-- ══════════════════════════════════════════════════════════════════
-- KNL QUALITY HUB — Supabase Setup
-- Ejecutar completo en SQL Editor
-- ══════════════════════════════════════════════════════════════════

-- ── TABLA AUDITORÍAS (Finca) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS auditorias (
  id                UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  registro_num      TEXT,
  tipo              TEXT DEFAULT 'finca',
  farm_name         TEXT,
  farm_short        TEXT,
  inspector         TEXT,
  variedad          TEXT,
  medida_cm         INTEGER,
  mesas             TEXT,
  fecha_auditoria   DATE,
  hora_inspeccion   TEXT,
  tipo_orden        TEXT,
  decision          TEXT,
  decision_label    TEXT,
  cancel_cantidad   TEXT,
  cancel_variedad   TEXT,
  cancel_longitud   TEXT,
  cancel_caja       TEXT,
  cancel_tallos     TEXT,
  score_total       INTEGER,
  calificacion      TEXT,
  fotos_count       INTEGER DEFAULT 0,
  novedades         TEXT,
  -- Secciones finca
  score_ramo        INTEGER,
  score_flores      INTEGER,
  score_tallos      INTEGER,
  score_follaje     INTEGER,
  score_sanidad     INTEGER,
  -- Carguera
  guia              TEXT,
  cliente           TEXT,
  empacador         TEXT,
  empaque_tallos    INTEGER,
  cajas             INTEGER,
  -- Items individuales (finca)
  score_item_6      INTEGER,
  score_item_7      INTEGER,
  score_item_8      INTEGER,
  score_item_9      INTEGER,
  score_item_10     INTEGER,
  score_item_11     INTEGER,
  score_item_12     INTEGER,
  score_item_13     INTEGER,
  score_item_14     INTEGER,
  score_item_15     INTEGER,
  score_item_16     INTEGER,
  score_item_17     INTEGER,
  score_item_18     INTEGER,
  score_item_19     INTEGER,
  score_item_20     INTEGER,
  score_item_21     INTEGER,
  score_item_22     INTEGER,
  score_item_23     INTEGER,
  score_item_24     INTEGER,
  score_item_25     INTEGER,
  score_item_26     INTEGER,
  score_item_27     INTEGER,
  score_item_28     INTEGER,
  score_item_29     INTEGER,
  score_item_30     INTEGER,
  score_item_31     INTEGER,
  score_item_32     INTEGER,
  score_item_33     INTEGER,
  score_item_34     INTEGER,
  score_item_35     INTEGER,
  score_item_36     INTEGER,
  score_item_37     INTEGER,
  score_item_38     INTEGER,
  score_item_39     INTEGER,
  score_item_40     INTEGER,
  -- Items carguera
  score_c1          INTEGER,
  score_c2          INTEGER,
  score_c3          INTEGER,
  score_c4          INTEGER,
  score_c5          INTEGER,
  score_c6          INTEGER,
  score_c7          INTEGER,
  score_c8          INTEGER,
  score_c9          INTEGER,
  score_c10         INTEGER,
  score_c11         INTEGER,
  score_c12         INTEGER,
  score_c13         INTEGER,
  score_c14         INTEGER,
  score_c15         INTEGER,
  score_c16         INTEGER,
  score_c17         INTEGER,
  -- Metadata
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLA USUARIOS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre      TEXT NOT NULL,
  rol         TEXT DEFAULT 'Inspector',
  zona        TEXT,
  email       TEXT,
  whatsapp    TEXT,
  initials    TEXT,
  color       TEXT,
  pin         TEXT,
  activo      BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLA FINCAS (ediciones personalizadas) ───────────────────────
CREATE TABLE IF NOT EXISTS fincas_edits (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  short       TEXT UNIQUE NOT NULL,
  rep         TEXT,
  email1      TEXT,
  email2      TEXT,
  whatsapp    TEXT,
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLA VARIEDADES EXTRA ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS variedades_extra (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre      TEXT UNIQUE NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── ÍNDICES para búsquedas rápidas ───────────────────────────────
CREATE INDEX IF NOT EXISTS idx_auditorias_fecha     ON auditorias(fecha_auditoria DESC);
CREATE INDEX IF NOT EXISTS idx_auditorias_farm      ON auditorias(farm_short);
CREATE INDEX IF NOT EXISTS idx_auditorias_tipo      ON auditorias(tipo);
CREATE INDEX IF NOT EXISTS idx_auditorias_inspector ON auditorias(inspector);

-- ── ROW LEVEL SECURITY (RLS) — acceso libre por ahora ────────────
ALTER TABLE auditorias       ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios         ENABLE ROW LEVEL SECURITY;
ALTER TABLE fincas_edits     ENABLE ROW LEVEL SECURITY;
ALTER TABLE variedades_extra ENABLE ROW LEVEL SECURITY;

-- Políticas permisivas (la app maneja autenticación internamente)
CREATE POLICY "allow_all_auditorias"       ON auditorias       FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_usuarios"         ON usuarios         FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_fincas_edits"     ON fincas_edits     FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_variedades_extra" ON variedades_extra FOR ALL USING (true) WITH CHECK (true);

-- ── USUARIOS INICIALES ────────────────────────────────────────────
INSERT INTO usuarios (nombre, rol, zona, email, whatsapp, initials, color, pin) VALUES
  ('Jefferson Revelo', 'Administrador', 'KNL Flores B.V.',    'jeff@fleuphoria.com',  '+593969117354', 'JR', '#f0c040', '1234'),
  ('Kevin Alencastro', 'Inspector',     'Ecuador Norte',       '',                     '+593961492638', 'KA', '#2dcc70', '5678'),
  ('Hector Guatemal',  'Inspector',     'Ecuador Sur',         '',                     '+593979407118', 'HG', '#3090f0', '9012'),
  ('Ayde Gualacata',   'Asistente',     'Administración',      'info@fleuphoria.com',  '+593985278678', 'AG', '#f08020', '3456')
ON CONFLICT DO NOTHING;

-- ── TRIGGER: updated_at automático ────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_auditorias_updated_at
  BEFORE UPDATE ON auditorias
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ══════════════════════════════════════════════════════════════════
-- ✅ LISTO — Todas las tablas creadas
-- ══════════════════════════════════════════════════════════════════
