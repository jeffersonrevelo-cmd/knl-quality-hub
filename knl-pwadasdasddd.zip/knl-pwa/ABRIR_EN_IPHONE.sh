#!/bin/bash
# KNL Quality Hub — Servidor local para Mac
# Ejecuta este script para abrir la app en tu iPhone por WiFi

echo "🌹 KNL Quality Hub — Servidor Local"
echo "======================================"

# Get local IP
IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "localhost")

echo ""
echo "📱 Para abrir en tu iPhone:"
echo "   Asegúrate de que iPhone y Mac estén en el mismo WiFi"
echo "   Abre Safari en tu iPhone y ve a:"
echo ""
echo "   👉  http://$IP:8080"
echo ""
echo "   Luego: compartir → Añadir a pantalla de inicio"
echo ""
echo "🖥️  En tu Mac: http://localhost:8080"
echo ""
echo "   Presiona Ctrl+C para detener"
echo "======================================"

# Start server in this folder
cd "$(dirname "$0")"
python3 -m http.server 8080
