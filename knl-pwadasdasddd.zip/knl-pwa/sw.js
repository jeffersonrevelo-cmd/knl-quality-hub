// KNL Quality Hub — Service Worker v4
// iOS offline-first: precache agresivo

const CACHE = 'knl-v4';

self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open(CACHE).then(function(cache){
      // Fetch and cache index.html explicitly
      return fetch('/index.html').then(function(res){
        return cache.put('/index.html', res);
      }).then(function(){
        return fetch('/').then(function(res){
          return cache.put('/', res);
        });
      }).then(function(){
        // Cache other assets silently
        var others = ['/manifest.json','/dashboard.html','/icons/icon-192x192.png','/icons/icon-512x512.png','/icons/apple-touch-icon.png'];
        return Promise.allSettled(others.map(function(url){
          return fetch(url).then(function(res){ return cache.put(url, res); }).catch(function(){});
        }));
      });
    }).then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(e){
  e.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k !== CACHE; })
            .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(e){
  var url = e.request.url;
  if(e.request.method !== 'GET') return;
  if(url.startsWith('chrome-extension')) return;

  // Supabase — Network First, empty array fallback offline
  if(url.includes('supabase.co')){
    e.respondWith(
      fetch(e.request.clone()).then(function(res){
        if(res.ok){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
        }
        return res;
      }).catch(function(){
        return caches.match(e.request).then(function(cached){
          return cached || new Response('[]', {headers:{'Content-Type':'application/json'}});
        });
      })
    );
    return;
  }

  // Fonts — cache first
  if(url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com')){
    e.respondWith(
      caches.match(e.request).then(function(cached){
        if(cached) return cached;
        return fetch(e.request).then(function(res){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
          return res;
        }).catch(function(){ return new Response(''); });
      })
    );
    return;
  }

  // Everything else — Cache First, ALWAYS return index.html as fallback
  e.respondWith(
    caches.match(e.request).then(function(cached){
      if(cached) return cached;
      return fetch(e.request).then(function(res){
        if(res.ok){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
        }
        return res;
      }).catch(function(){
        // Offline fallback — always serve index.html for navigation
        return caches.match('/index.html').then(function(page){
          return page || new Response('Offline', {status:503});
        });
      });
    })
  );
});
