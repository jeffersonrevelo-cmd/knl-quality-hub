# CONECTAR SUPABASE — KNL Quality Hub
# Tiempo: 10 minutos · Gratis para siempre

═══════════════════════════════════════════════════════
PASO 1 — Crear cuenta y proyecto
═══════════════════════════════════════════════════════

1. Ve a https://app.supabase.com
2. "Sign Up" con tu email o Google
3. "New Project"
   - Organization: KNL Flores
   - Name: knl-quality-hub
   - Database Password: (guárdala, la necesitarás)
   - Region: EU West (Ireland) — más cerca de Holanda
4. Espera ~2 minutos mientras crea el proyecto

═══════════════════════════════════════════════════════
PASO 2 — Crear la tabla de auditorías
═══════════════════════════════════════════════════════

1. En Supabase, ve a "SQL Editor" (icono de código)
2. Clic en "New Query"
3. Pega y ejecuta este SQL:

-- Tabla principal de auditorías KNL
CREATE TABLE auditorias (
  id              BIGSERIAL PRIMARY KEY,
  registro_num    TEXT UNIQUE,
  farm_name       TEXT NOT NULL,
  farm_short      TEXT,
  inspector       TEXT,
  variedad        TEXT,
  medida_cm       INTEGER,
  mesas           TEXT,
  fecha_auditoria DATE DEFAULT CURRENT_DATE,
  hora_inspeccion TEXT,
  tipo_orden      TEXT DEFAULT 'fixed',
  score_total     INTEGER,
  score_ramo      INTEGER,
  score_flores    INTEGER,
  score_tallos    INTEGER,
  score_follaje   INTEGER,
  score_sanidad   INTEGER,
  calificacion    TEXT,
  fotos_count     INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Permitir acceso desde la app (sin login por ahora)
ALTER TABLE auditorias ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Acceso público temporal" ON auditorias
  FOR ALL USING (true) WITH CHECK (true);

4. Clic en "Run" — debe decir "Success"

═══════════════════════════════════════════════════════
PASO 3 — Obtener tus credenciales
═══════════════════════════════════════════════════════

1. Ve a Settings → API (en el menú lateral)
2. Copia estos dos valores:

   Project URL:  https://XXXXXXXX.supabase.co
   anon public:  eyJhbGciOiJIUzI1NiIsInR...

═══════════════════════════════════════════════════════
PASO 4 — Pegar credenciales en el index.html
═══════════════════════════════════════════════════════

1. Abre index.html en cualquier editor de texto
2. Busca estas dos líneas (cerca del final del archivo):

   var SUPABASE_URL  = "";
   var SUPABASE_KEY  = "";

3. Pega tus credenciales:

   var SUPABASE_URL  = "https://XXXXXXXX.supabase.co";
   var SUPABASE_KEY  = "eyJhbGciOiJIUzI1NiIsInR...";

4. Guarda el archivo

═══════════════════════════════════════════════════════
PASO 5 — Volver a subir a Netlify
═══════════════════════════════════════════════════════

1. Ve a app.netlify.com → tu site → Deploys
2. Arrastra la carpeta knl-pwa/ actualizada
3. Netlify despliega en ~30 segundos

═══════════════════════════════════════════════════════
VERIFICAR QUE FUNCIONA
═══════════════════════════════════════════════════════

1. Abre la app en tu iPhone
2. Selecciona una finca → completa auditoría rápida
3. Toca "Guardar y enviar"
4. Debe aparecer toast "✓ Guardado"
5. Ve a Supabase → Table Editor → auditorias
6. La fila debe aparecer ahí

Si dice "Guardado local" en vez de "✓ Guardado":
→ Revisa que las credenciales estén bien pegadas
→ Revisa que la tabla se creó correctamente

═══════════════════════════════════════════════════════
SIN SUPABASE — también funciona
═══════════════════════════════════════════════════════

Si dejas SUPABASE_URL vacío, la app funciona igual
pero guarda las auditorías en el teléfono (localStorage).
Cuando configures Supabase, las futuras auditorías
irán a la nube automáticamente.

═══════════════════════════════════════════════════════
PRÓXIMOS PASOS DESPUÉS DE SUPABASE
═══════════════════════════════════════════════════════

→ Login real (Kevin, Hector, Jefferson con password)
→ Ver historial de auditorías en la app
→ Dashboard web para Jefferson (en el navegador)
→ Notificaciones WhatsApp Business API
→ Compartir URL con Ayde para que vea scores en vivo
