const ANTHROPIC_KEY = "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";

exports.handler = async function(event) {
  if(event.httpMethod !== "POST"){
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const body = JSON.parse(event.body);
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1024,
        messages: body.messages
      })
    });

    const data = await response.json();
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    };
  } catch(err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
